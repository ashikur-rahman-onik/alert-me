/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DEFAULT_PIN_HASH } from '../types/settings.ts';

/**
 * স্ট্যাটিক সল্ট (Salt) - লোকাল পিন এনক্রিপশনের জন্য
 */
const PIN_SALT = 'alert_me_offline_salt_v1';

/**
 * পিন কোডের SHA-256 হ্যাশ তৈরি করে (ওয়েব ক্রিপ্টো এপিআই ব্যবহার করে)
 * এটি প্লেইনটেক্সট হিসেবে স্টোরেজে সংরক্ষণ রোধ করে।
 */
export async function hashPin(pin: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(pin + PIN_SALT);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

/**
 * ব্যবহারকারীর ইনপুট করা পিন সংরক্ষিত হ্যাশের সাথে যাচাই করে
 */
export async function verifyPin(inputPin: string, storedHash: string): Promise<boolean> {
  if (!storedHash) return false;
  const inputHash = await hashPin(inputPin);
  return inputHash === storedHash;
}

/**
 * নিরাপদ পিন পরিবর্তন প্রক্রিয়া
 */
export async function changePin(
  currentPin: string,
  newPin: string,
  currentHash: string
): Promise<{ success: boolean; newHash?: string; error?: string }> {
  if (newPin.length !== 4 || !/^\d{4}$/.test(newPin)) {
    return { success: false, error: 'নতুন পিন অবশ্যই ৪ সংখ্যার হতে হবে।' };
  }

  const isCurrentValid = await verifyPin(currentPin, currentHash);
  if (!isCurrentValid) {
    return { success: false, error: 'বর্তমান পিন কোডটি ভুল।' };
  }

  const newHash = await hashPin(newPin);
  return { success: true, newHash };
}

/**
 * ডিফল্ট পিন রিসেট (শুধুমাত্র IDLE অবস্থায় অনুমোদিত)
 */
export function getDefaultPinHash(): string {
  return DEFAULT_PIN_HASH;
}
