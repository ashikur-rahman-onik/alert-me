/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AppSettings, DEFAULT_SETTINGS, STORAGE_KEY_SETTINGS, SENSITIVITY_THRESHOLDS } from '../types/settings.ts';

/**
 * লোকাল স্টোরেজ থেকে বিশ্বস্তভাবে সেটিংস লোড করার ফাংশন
 */
export function loadLocalSettings(): AppSettings {
  try {
    const rawData = localStorage.getItem(STORAGE_KEY_SETTINGS);
    if (!rawData) {
      return { ...DEFAULT_SETTINGS };
    }

    const parsed = JSON.parse(rawData);
    const merged: AppSettings = {
      ...DEFAULT_SETTINGS,
      ...parsed,
    };

    // সংবেদনশীলতা মান অনুযায়ী মোশন থ্রেশহোল্ড সিঙ্ক রাখা
    if (merged.sensitivity in SENSITIVITY_THRESHOLDS) {
      merged.motionThreshold = SENSITIVITY_THRESHOLDS[merged.sensitivity];
    }

    // পিনহ্যাশ শূন্য থাকলে ডিফল্ট হ্যাশ দেওয়া
    if (!merged.pinHash) {
      merged.pinHash = DEFAULT_SETTINGS.pinHash;
    }

    return merged;
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

/**
 * ডিভাইসের লোকাল স্টোরেজে সেটিংস সংরক্ষণ করার ফাংশন
 */
export function saveLocalSettings(settings: AppSettings): boolean {
  try {
    localStorage.setItem(STORAGE_KEY_SETTINGS, JSON.stringify(settings));
    return true;
  } catch {
    return false;
  }
}
