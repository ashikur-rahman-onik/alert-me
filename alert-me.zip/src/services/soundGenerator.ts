/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AlarmToneType } from '../types/settings.ts';

/**
 * অফলাইন ও নির্ভরতামুক্ত ওয়েব অডিও সিন্থেসাইজার
 * ব্রাউজার বা ওয়েব ভিউতে রিয়েল-টাইমে সাইরেন ও অ্যালার্ম শব্দ তৈরির জন্য।
 */
class SoundGenerator {
  private ctx: AudioContext | null = null;
  private oscillator: OscillatorNode | null = null;
  private gainNode: GainNode | null = null;
  private isPlaying = false;
  private intervalTimer: number | null = null;

  private initContext() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public startAlarm(tone: AlarmToneType = 'siren', volume: number = 100) {
    if (this.isPlaying) return;
    this.initContext();
    if (!this.ctx) return;

    this.isPlaying = true;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    const normalizedVol = Math.max(0.01, Math.min(1.0, volume / 100));
    gain.gain.setValueAtTime(normalizedVol, this.ctx.currentTime);

    osc.type = 'sawtooth';
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    this.oscillator = osc;
    this.gainNode = gain;

    const startTime = this.ctx.currentTime;
    osc.start(startTime);

    if (tone === 'police') {
      // ডুয়াল টোন সাইরেন (Hi-Lo 700Hz - 1100Hz)
      let toggle = false;
      this.intervalTimer = window.setInterval(() => {
        if (!this.oscillator || !this.ctx) return;
        const targetFreq = toggle ? 720 : 1150;
        this.oscillator.frequency.cancelScheduledValues(this.ctx.currentTime);
        this.oscillator.frequency.setTargetAtTime(targetFreq, this.ctx.currentTime, 0.05);
        toggle = !toggle;
      }, 400);
    } else if (tone === 'radar') {
      // পালসিং ওয়ার্নিং বীপ (1500Hz)
      this.intervalTimer = window.setInterval(() => {
        if (!this.oscillator || !this.gainNode || !this.ctx) return;
        this.oscillator.frequency.setValueAtTime(1400, this.ctx.currentTime);
        this.gainNode.gain.cancelScheduledValues(this.ctx.currentTime);
        this.gainNode.gain.setValueAtTime(normalizedVol, this.ctx.currentTime);
        this.gainNode.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.25);
      }, 350);
    } else {
      // ক্লাসিক সাইরেন (সুইপিং ফ্রিকোয়েন্সি 600Hz - 1400Hz)
      const now = this.ctx.currentTime;
      osc.frequency.setValueAtTime(650, now);
      // রিকারিং ফ্রিকোয়েন্সি মডুলেশন
      let up = true;
      this.intervalTimer = window.setInterval(() => {
        if (!this.oscillator || !this.ctx) return;
        const targetFreq = up ? 1450 : 650;
        this.oscillator.frequency.cancelScheduledValues(this.ctx.currentTime);
        this.oscillator.frequency.exponentialRampToValueAtTime(targetFreq, this.ctx.currentTime + 0.65);
        up = !up;
      }, 700);
    }
  }

  public stopAlarm() {
    if (this.intervalTimer !== null) {
      clearInterval(this.intervalTimer);
      this.intervalTimer = null;
    }
    if (this.oscillator) {
      try {
        this.oscillator.stop();
        this.oscillator.disconnect();
      } catch {
        // ইতোমধ্যে বন্ধ থাকলে এড়িয়ে যাওয়া
      }
      this.oscillator = null;
    }
    if (this.gainNode) {
      this.gainNode.disconnect();
      this.gainNode = null;
    }
    this.isPlaying = false;
  }

  public playBeep(freq: number = 880, durationMs: number = 150) {
    this.initContext();
    if (!this.ctx) return;

    try {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
      gain.gain.setValueAtTime(0.3, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + durationMs / 1000);
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + durationMs / 1000);
    } catch {
      // নো-অফ
    }
  }
}

export const soundGenerator = new SoundGenerator();
