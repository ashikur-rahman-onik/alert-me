/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Capacitor, registerPlugin, PluginListenerHandle } from '@capacitor/core';
import { AppSettings, AlarmMachineState } from '../types/settings.ts';

/**
 * নেটিভ প্লাগইন থেকে প্রাপ্ত অ্যালার্ম স্টেট ইভেন্ট
 */
export interface NativeAlarmStateEvent {
  state: AlarmMachineState;
  reason?: string;
  timestamp: number;
}

/**
 * ক্যাপাসিটর প্লাগইন ইন্টারফেস
 */
export interface AlertMeNativePlugin {
  startAlarm(options: {
    threshold: number;
    armDelaySeconds: number;
    volumeLevel: number;
    vibrationEnabled: boolean;
  }): Promise<{ success: boolean; state: AlarmMachineState; message?: string }>;

  stopAlarm(): Promise<{ success: boolean; state: AlarmMachineState }>;

  getAlarmState(): Promise<{ state: AlarmMachineState }>;

  checkPermissions(): Promise<{
    hasNotificationPermission: boolean;
    hasAccelerometer: boolean;
    canUseFullScreenIntent: boolean;
  }>;

  requestNotificationPermission(): Promise<{ granted: boolean }>;

  openUrl(options: { url: string }): Promise<{ success: boolean }>;

  addListener(
    eventName: 'alarmStateChange',
    listenerFunc: (event: NativeAlarmStateEvent) => void
  ): Promise<PluginListenerHandle>;
}

// ক্যাপাসিটর নেটিভ প্লাগইন ইনস্ট্যান্স
export const AlertMeNative = registerPlugin<AlertMeNativePlugin>('AlertMeNative');

class NativeBridge {
  private stateChangeListeners: ((state: AlarmMachineState, reason?: string) => void)[] = [];
  private nativeListenerHandle: PluginListenerHandle | null = null;

  constructor() {
    this.initNativeListener();
  }

  private async initNativeListener() {
    if (this.isNativeAndroid()) {
      try {
        this.nativeListenerHandle = await AlertMeNative.addListener('alarmStateChange', (event) => {
          this.notifyStateListeners(event.state, event.reason);
        });
      } catch {
        // প্লাগইন এখনও রেডি না হলে বা ত্রুটি হলে
      }
    }
  }

  public isNative(): boolean {
    return Capacitor.isNativePlatform();
  }

  public isNativeAndroid(): boolean {
    return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
  }

  public getPlatformName(): 'android' | 'web' {
    return this.isNativeAndroid() ? 'android' : 'web';
  }

  /**
   * স্টেট পরিবর্তন লিসেনার নিবন্ধন
   */
  public onStateChange(callback: (state: AlarmMachineState, reason?: string) => void): () => void {
    this.stateChangeListeners.push(callback);
    return () => {
      this.stateChangeListeners = this.stateChangeListeners.filter(cb => cb !== callback);
    };
  }

  public notifyStateListeners(state: AlarmMachineState, reason?: string) {
    this.stateChangeListeners.forEach(cb => cb(state, reason));
  }

  /**
   * অ্যান্ড্রয়েড নেটিভ ফোরগ্রাউন্ড সার্ভিস চালুর নির্দেশ
   */
  public async startAlarmService(settings: AppSettings): Promise<{ success: boolean; mode: 'native' | 'web'; message?: string }> {
    if (!this.isNativeAndroid()) {
      // ব্রাউজার প্রিভিউ মোড
      return { success: true, mode: 'web' };
    }

    try {
      const res = await AlertMeNative.startAlarm({
        threshold: settings.motionThreshold,
        armDelaySeconds: settings.armDelaySeconds,
        volumeLevel: settings.volumeLevel,
        vibrationEnabled: settings.vibrationEnabled,
      });

      return { 
        success: res.success, 
        mode: 'native', 
        message: res.message 
      };
    } catch (err) {
      return { 
        success: false, 
        mode: 'native', 
        message: err instanceof Error ? err.message : 'নেটিভ সার্ভিস চালু করা যায়নি।' 
      };
    }
  }

  /**
   * অ্যালার্ম বন্ধ করার নির্দেশ
   */
  public async stopAlarmService(): Promise<{ success: boolean; mode: 'native' | 'web'; message?: string }> {
    if (!this.isNativeAndroid()) {
      return { success: true, mode: 'web' };
    }

    try {
      const res = await AlertMeNative.stopAlarm();
      return { success: res.success, mode: 'native' };
    } catch (err) {
      return { 
        success: false, 
        mode: 'native',
        message: err instanceof Error ? err.message : 'সার্ভিস বন্ধ করতে সমস্যা হয়েছে।'
      };
    }
  }

  /**
   * বর্তমান পারমিশন ও সেন্সর স্ট্যাটাস পরীক্ষা
   */
  public async checkPermissions(): Promise<{ hasNotificationPermission: boolean; hasAccelerometer: boolean }> {
    if (!this.isNativeAndroid()) {
      return { hasNotificationPermission: true, hasAccelerometer: true };
    }

    try {
      const res = await AlertMeNative.checkPermissions();
      return { 
        hasNotificationPermission: res.hasNotificationPermission,
        hasAccelerometer: res.hasAccelerometer
      };
    } catch {
      return { hasNotificationPermission: false, hasAccelerometer: true };
    }
  }

  /**
   * নোটিফিকেশন পারমিশনের অনুরোধ
   */
  public async requestNotificationPermission(): Promise<boolean> {
    if (!this.isNativeAndroid()) {
      return true;
    }

    try {
      const res = await AlertMeNative.requestNotificationPermission();
      return res.granted;
    } catch {
      return false;
    }
  }

  /**
   * বাহ্যিক লিংক বা APK ডাউনলোড লিংক খোলা
   */
  public async openExternalUrl(url: string): Promise<boolean> {
    if (this.isNativeAndroid()) {
      try {
        const res = await AlertMeNative.openUrl({ url });
        return res.success;
      } catch {
        // ফলব্যাক
        window.open(url, '_system');
        return true;
      }
    } else {
      window.open(url, '_blank', 'noopener,noreferrer');
      return true;
    }
  }
}

export const nativeBridge = new NativeBridge();

