/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { APP_CONFIG } from '../config/appConfig.ts';

export interface GitHubReleaseAsset {
  id: number;
  name: string;
  size: number;
  browser_download_url: string;
  content_type: string;
}

export interface GitHubReleaseResponse {
  tag_name: string;
  name: string;
  body: string;
  published_at: string;
  prerelease: boolean;
  draft: boolean;
  html_url: string;
  assets: GitHubReleaseAsset[];
}

export interface UpdateCheckResult {
  hasUpdate: boolean;
  installedVersion: string;
  latestVersion: string;
  releaseTitle?: string;
  releaseNotes?: string;
  publishedAt?: string;
  isPrerelease?: boolean;
  htmlUrl?: string;
  apkAsset?: {
    name: string;
    sizeFormatted: string;
    downloadUrl: string;
  };
  errorMessage?: string;
}

/**
 * সেমান্টিক ভার্সন পার্স করার ফাংশন
 * উদাহরণ: 'v1.2.3-beta.1' -> { major: 1, minor: 2, patch: 3, prerelease: 'beta.1' }
 */
export function parseSemVer(versionStr: string): { major: number; minor: number; patch: number; prerelease: string } {
  const clean = versionStr.trim().replace(/^v/i, '');
  const [core, ...preParts] = clean.split('-');
  const prerelease = preParts.join('-');

  const parts = core.split('.').map((p) => {
    const num = parseInt(p, 10);
    return isNaN(num) ? 0 : num;
  });

  return {
    major: parts[0] ?? 0,
    minor: parts[1] ?? 0,
    patch: parts[2] ?? 0,
    prerelease: prerelease || '',
  };
}

/**
 * দুটি সেমান্টিক ভার্সন তুলনা করার ফাংশন
 * রিটার্ন:
 *   ১: v1 > v2 (নতুন সংস্করণ বিদ্যমান)
 *   ০: v1 == v2
 *  -১: v1 < v2
 */
export function compareSemVer(v1: string, v2: string): number {
  const sem1 = parseSemVer(v1);
  const sem2 = parseSemVer(v2);

  if (sem1.major !== sem2.major) return sem1.major > sem2.major ? 1 : -1;
  if (sem1.minor !== sem2.minor) return sem1.minor > sem2.minor ? 1 : -1;
  if (sem1.patch !== sem2.patch) return sem1.patch > sem2.patch ? 1 : -1;

  // প্রিলিজ তুলনা: প্রিলিজ থাকলে সাধারণত মূল রিলিজের চেয়ে পুরোনো বিবেচিত হয়
  if (!sem1.prerelease && sem2.prerelease) return 1;
  if (sem1.prerelease && !sem2.prerelease) return -1;
  if (sem1.prerelease && sem2.prerelease) {
    return sem1.prerelease.localeCompare(sem2.prerelease);
  }

  return 0;
}

/**
 * বাইটকে মেগাবাইট বা কিলোবাইটে রূপান্তর
 */
export function formatBytes(bytes: number): string {
  if (bytes <= 0) return '০ B';
  const mb = bytes / (1024 * 1024);
  if (mb >= 1) {
    return `${mb.toFixed(1)} MB`;
  }
  const kb = bytes / 1024;
  return `${kb.toFixed(0)} KB`;
}

/**
 * গিটহাব রিলিজ থেকে নতুন আপডেট যাচাই করার ফাংশন
 */
export async function checkForAppUpdate(): Promise<UpdateCheckResult> {
  const installedVersion = APP_CONFIG.versionName;

  if (typeof navigator !== 'undefined' && !navigator.onLine) {
    return {
      hasUpdate: false,
      installedVersion,
      latestVersion: installedVersion,
      errorMessage: 'ইন্টারনেট সংযোগ পাওয়া যায়নি। অফলাইন মোডে আপডেট পরীক্ষা সম্ভব নয়।',
    };
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000); // ১০ সেকেন্ড টাইমআউট

    const res = await fetch(APP_CONFIG.github.apiLatestReleaseUrl, {
      method: 'GET',
      headers: {
        Accept: 'application/vnd.github.v3+json',
      },
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (res.status === 404) {
      return {
        hasUpdate: false,
        installedVersion,
        latestVersion: installedVersion,
        errorMessage: 'গিটহাবে এখনও কোনো অফিসিয়াল রিলিজ প্রকাশিত হয়নি।',
      };
    }

    if (res.status === 403 || res.status === 429) {
      return {
        hasUpdate: false,
        installedVersion,
        latestVersion: installedVersion,
        errorMessage: 'গিটহাব এপিআই রেট লিমিট অতিক্রম করেছে। কিছুক্ষণ পর পুনরায় চেষ্টা করুন।',
      };
    }

    if (!res.ok) {
      return {
        hasUpdate: false,
        installedVersion,
        latestVersion: installedVersion,
        errorMessage: `সার্ভার রেসপন্স ব্যর্থ হয়েছে (কোড: ${res.status})।`,
      };
    }

    const data: GitHubReleaseResponse = await res.json();
    const latestRawVersion = data.tag_name || data.name || installedVersion;
    const latestVersion = latestRawVersion.trim().replace(/^v/i, '');

    // সেমান্টিক ভার্সন তুলনা
    const hasUpdate = compareSemVer(latestVersion, installedVersion) > 0;

    // বিশ্বস্ত APK অ্যাসেট অনুসন্ধান
    const apkAsset = data.assets?.find((asset) => {
      const isApk = APP_CONFIG.trustedApkPattern.test(asset.name);
      const isTrustedHost = asset.browser_download_url.startsWith('https://github.com/');
      return isApk && isTrustedHost;
    });

    return {
      hasUpdate,
      installedVersion,
      latestVersion,
      releaseTitle: data.name || data.tag_name,
      releaseNotes: data.body || 'কোনো রিলিজ নোট প্রদান করা হয়নি।',
      publishedAt: data.published_at ? new Date(data.published_at).toLocaleDateString('bn-BD') : undefined,
      isPrerelease: data.prerelease,
      htmlUrl: data.html_url || APP_CONFIG.github.releasesPageUrl,
      apkAsset: apkAsset
        ? {
            name: apkAsset.name,
            sizeFormatted: formatBytes(apkAsset.size),
            downloadUrl: apkAsset.browser_download_url,
          }
        : undefined,
    };
  } catch (err) {
    if (err instanceof Error && err.name === 'AbortError') {
      return {
        hasUpdate: false,
        installedVersion,
        latestVersion: installedVersion,
        errorMessage: 'নেটওয়ার্ক অনুরোধের সময় শেষ হয়ে গেছে। অনুগ্রহ করে ইন্টারনেট সংযোগ পরীক্ষা করুন।',
      };
    }

    return {
      hasUpdate: false,
      installedVersion,
      latestVersion: installedVersion,
      errorMessage: 'আপডেট সার্ভারের সাথে যোগাযোগ করা সম্ভব হয়নি।',
    };
  }
}
