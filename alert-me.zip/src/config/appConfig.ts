/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Alert Me অ্যাপ্লিকেশন কনফিগারেশন এবং সংস্করণ পরিচিতি
 */
export const APP_CONFIG = {
  name: 'Alert Me',
  applicationId: 'com.alertme.antitheft',
  versionName: '1.0.0',
  versionCode: 1,

  // অফিসিয়াল গিটহাব রেপোজিটরি কনফিগারেশন (ইন-অ্যাপ আপডেটের জন্য)
  github: {
    owner: 'anikszone',
    repo: 'alert-me',
    releasesPageUrl: 'https://github.com/anikszone/alert-me/releases',
    apiLatestReleaseUrl: 'https://api.github.com/repos/anikszone/alert-me/releases/latest',
  },

  // বিশ্বস্ত এপিকে অ্যাসেটের নাম প্যাটার্ন (শুধুমাত্র .apk ফাইল)
  trustedApkPattern: /\.apk$/i,
} as const;
