/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * মোশন সেন্সিটিভিটি লেভেল
 */
export type MotionSensitivity = 'low' | 'medium' | 'high';

/**
 * অ্যালার্ম টোন প্রিসেট
 */
export type AlarmToneType = 'siren' | 'police' | 'radar';

/**
 * অ্যালার্মের সুনির্দিষ্ট স্টেট মেশিন (State Machine)
 */
export type AlarmMachineState = 'IDLE' | 'ARMING' | 'ARMED' | 'ALARMING' | 'STOPPING';

/**
 * অ্যাপ্লিকেশন সেটিংস ইন্টারফেস (সম্পূর্ণ অফলাইন এবং লোকাল)
 */
export interface AppSettings {
  /**
   * ফোন রাখার জন্য আর্ম হওয়ার পূর্বে বিলম্ব (সেকেন্ড)
   * ডিফল্ট: ৫ সেকেন্ড
   */
  armDelaySeconds: number;

  /**
   * মোশন সেন্সর সংবেদনশীলতা
   * ডিফল্ট: medium
   */
  sensitivity: MotionSensitivity;

  /**
   * মোশন শনাক্তকরণ থ্রেশহোল্ড (ত্বরণ পার্থক্য m/s²)
   */
  motionThreshold: number;

  /**
   * অ্যালার্ম বন্ধ করার জন্য পিন সুরক্ষার সক্রিয়তা
   * ডিফল্ট: true
   */
  pinProtectionEnabled: boolean;

  /**
   * সল্টেড SHA-256 পিন হ্যাশ (কোনো প্লেইনটেক্সট পিন সংরক্ষণ করা হয় না)
   */
  pinHash: string;

  /**
   * অ্যালার্ম টোন নির্বাচন
   */
  alarmTone: AlarmToneType;

  /**
   * অ্যালার্ম ভলিউম (০ থেকে ১০০)
   */
  volumeLevel: number;

  /**
   * অ্যালার্মের সময় ভাইব্রেশন সক্রিয় থাকবে কি না
   */
  vibrationEnabled: boolean;

  /**
   * একটানা অ্যালার্ম বাজার সর্বোচ্চ সময়সীমা (সেকেন্ড)
   */
  maxAlarmDurationSeconds: number;
}

/**
 * সেন্সিটিভিটি অনুযায়ী থ্রেশহোল্ডের মান (m/s²)
 */
export const SENSITIVITY_THRESHOLDS: Record<MotionSensitivity, number> = {
  low: 3.5,     // ভারী ঝাঁকুনি বা স্পষ্ট স্থানান্তরের জন্য
  medium: 1.8,  // স্বাভাবিক স্পর্শ বা ফোন উঠিয়ে নেওয়ার জন্য
  high: 0.8,    // সামান্যতম স্পর্শ বা নড়াচড়ার জন্য
};

/**
 * ডিফল্ট পিন '1234' এর জন্য প্রাক-গণনাকৃত SHA-256 সল্টেড হ্যাশ
 * (1234 + alert_me_offline_salt_v1)
 */
export const DEFAULT_PIN_HASH = '1326466c1b3f9479e05f63be3d4891b9efdfb7914f653457a3e351897e97495b';

/**
 * সিস্টেমের ডিফল্ট সেটিংস
 */
export const DEFAULT_SETTINGS: AppSettings = {
  armDelaySeconds: 5,
  sensitivity: 'medium',
  motionThreshold: SENSITIVITY_THRESHOLDS.medium,
  pinProtectionEnabled: true,
  pinHash: DEFAULT_PIN_HASH,
  alarmTone: 'siren',
  volumeLevel: 100,
  vibrationEnabled: true,
  maxAlarmDurationSeconds: 180,
};

/**
 * লোকাল স্টোরেজ কি (Key)
 */
export const STORAGE_KEY_SETTINGS = 'alert_me_local_settings_v2';
