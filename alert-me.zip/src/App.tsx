/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { 
  ShieldAlert, 
  ShieldCheck, 
  ShieldOff,
  Volume2, 
  VolumeX, 
  Sliders, 
  Lock, 
  Unlock,
  Smartphone,
  AlertTriangle,
  RotateCcw,
  Check,
  X,
  Settings as SettingsIcon,
  Bell,
  KeyRound,
  CheckCircle2,
  AlertCircle,
  Download,
  RefreshCw,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import { APP_CONFIG } from './config/appConfig.ts';
import { checkForAppUpdate, UpdateCheckResult } from './services/updateService.ts';
import { AppSettings, DEFAULT_SETTINGS, AlarmMachineState, MotionSensitivity, AlarmToneType } from './types/settings.ts';
import { loadLocalSettings, saveLocalSettings } from './services/storage.ts';
import { soundGenerator } from './services/soundGenerator.ts';
import { nativeBridge } from './services/nativeBridge.ts';
import { verifyPin, changePin, getDefaultPinHash } from './services/security.ts';


export default function App() {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [alarmState, setAlarmState] = useState<AlarmMachineState>('IDLE');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'settings' | 'audit'>('dashboard');

  // প্ল্যাটফর্ম এবং হার্ডওয়্যার পারমিশন অবস্থা
  const isAndroidNative = nativeBridge.isNativeAndroid();
  const [hasNotificationPerm, setHasNotificationPerm] = useState<boolean>(true);
  const [hasAccelerometer, setHasAccelerometer] = useState<boolean>(true);
  const [isCheckingHardware, setIsCheckingHardware] = useState<boolean>(false);

  // কাউন্টডাউন টাইমার
  const [countdown, setCountdown] = useState<number>(0);
  const countdownTimerRef = useRef<number | null>(null);

  // পিন আনলক মডাল (অ্যালার্ম বন্ধের জন্য)
  const [isPinModalOpen, setIsPinModalOpen] = useState<boolean>(false);
  const [pinInput, setPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [isVerifyingPin, setIsVerifyingPin] = useState<boolean>(false);

  // পিন পরিবর্তন মডাল (সেটিংসের জন্য)
  const [isChangePinModalOpen, setIsChangePinModalOpen] = useState<boolean>(false);
  const [currentPinInput, setCurrentPinInput] = useState<string>('');
  const [newPinInput, setNewPinInput] = useState<string>('');
  const [confirmPinInput, setConfirmPinInput] = useState<string>('');
  const [changePinError, setChangePinError] = useState<string | null>(null);
  const [changePinSuccess, setChangePinSuccess] = useState<string | null>(null);

  // অডিও টেস্ট স্টেট ও সিস্টেম বার্তা
  const [isTestSoundActive, setIsTestSoundActive] = useState<boolean>(false);
  const [statusNotification, setStatusNotification] = useState<{ message: string; type: 'info' | 'error' | 'success' } | null>(null);

  // ইন-অ্যাপ আপডেট চেকার স্টেট
  const [isCheckingUpdate, setIsCheckingUpdate] = useState<boolean>(false);
  const [updateResult, setUpdateResult] = useState<UpdateCheckResult | null>(null);

  // ১. প্রাথমিক সেটআপ ও হার্ডওয়্যার পারমিশন নিরীক্ষা
  useEffect(() => {
    const loaded = loadLocalSettings();
    setSettings(loaded);

    const checkSystemHardware = async () => {
      setIsCheckingHardware(true);
      try {
        const perms = await nativeBridge.checkPermissions();
        setHasNotificationPerm(perms.hasNotificationPermission);
        setHasAccelerometer(perms.hasAccelerometer);
      } catch {
        // ফলব্যাক
      } finally {
        setIsCheckingHardware(false);
      }
    };

    checkSystemHardware();

    // নেটিভ স্টেট লিসেনার নিবন্ধন
    const unsubscribe = nativeBridge.onStateChange((newState, reason) => {
      setAlarmState(newState);
      if (reason) {
        setStatusNotification({ message: reason, type: newState === 'ALARMING' ? 'error' : 'info' });
      }

      if (newState === 'ALARMING') {
        if (!isAndroidNative) {
          soundGenerator.startAlarm(settings.alarmTone, settings.volumeLevel);
        }
      } else if (newState === 'IDLE' || newState === 'STOPPING') {
        soundGenerator.stopAlarm();
      }
    });

    return () => {
      unsubscribe();
      if (countdownTimerRef.current !== null) {
        clearInterval(countdownTimerRef.current);
      }
    };
  }, [isAndroidNative, settings.alarmTone, settings.volumeLevel]);

  // নোটিফিকেশন পারমিশনের অনুরোধ
  const handleRequestNotificationPerm = async () => {
    const granted = await nativeBridge.requestNotificationPermission();
    setHasNotificationPerm(granted);
    if (granted) {
      setStatusNotification({ message: 'নোটিফিকেশন অনুমতি সফলভাবে প্রদান করা হয়েছে।', type: 'success' });
    } else {
      setStatusNotification({ message: 'নোটিফিকেশন অনুমতি প্রদান করা হয়নি। সেটিংস থেকে চালু করুন।', type: 'error' });
    }
  };

  // ২. অ্যালার্ম আর্ম করার প্রক্রিয়া
  const handleStartArming = async () => {
    setStatusNotification(null);

    if (!hasAccelerometer) {
      setStatusNotification({ message: 'ত্রুটি: এই ডিভাইসে অ্যাক্সিলারোমিটার সেন্সর পাওয়া যায়নি।', type: 'error' });
      return;
    }

    if (isAndroidNative && !hasNotificationPerm) {
      const granted = await nativeBridge.requestNotificationPermission();
      setHasNotificationPerm(granted);
      if (!granted) {
        setStatusNotification({ message: 'ফোরগ্রাউন্ড সার্ভিসের জন্য নোটিফিকেশন অনুমতি আবশ্যক।', type: 'error' });
        return;
      }
    }

    setAlarmState('ARMING');
    let remaining = settings.armDelaySeconds;
    setCountdown(remaining);

    countdownTimerRef.current = window.setInterval(async () => {
      remaining -= 1;
      setCountdown(remaining);

      if (remaining <= 0) {
        if (countdownTimerRef.current !== null) {
          clearInterval(countdownTimerRef.current);
          countdownTimerRef.current = null;
        }

        const result = await nativeBridge.startAlarmService(settings);
        if (result.success) {
          setAlarmState('ARMED');
          setStatusNotification({ message: 'ডিভাইস সফলভাবে সুরক্ষিত ও লক করা হয়েছে।', type: 'success' });
        } else {
          setAlarmState('IDLE');
          setStatusNotification({ message: result.message || 'সার্ভিস চালু করা সম্ভব হয়নি।', type: 'error' });
        }
      }
    }, 1000);
  };

  // ৩. প্রস্তুতি বাতিল
  const handleCancelArming = () => {
    if (countdownTimerRef.current !== null) {
      clearInterval(countdownTimerRef.current);
      countdownTimerRef.current = null;
    }
    setAlarmState('IDLE');
    setStatusNotification({ message: 'অ্যালার্ম প্রস্তুতি বাতিল করা হয়েছে।', type: 'info' });
  };

  // ৪. অ্যালার্ম বন্ধের অনুরোধ
  const handleRequestStop = () => {
    if (settings.pinProtectionEnabled) {
      setPinInput('');
      setPinError(null);
      setIsPinModalOpen(true);
    } else {
      executeStop();
    }
  };

  // ৫. স্টপ সম্পাদন
  const executeStop = async () => {
    setAlarmState('STOPPING');
    soundGenerator.stopAlarm();
    setIsTestSoundActive(false);

    const result = await nativeBridge.stopAlarmService();
    setAlarmState('IDLE');
    setIsPinModalOpen(false);
    setPinInput('');

    if (result.success) {
      setStatusNotification({ message: 'অ্যালার্ম সম্পূর্ণ বন্ধ ও সুরক্ষিতভাবে রিসেট হয়েছে।', type: 'success' });
    } else {
      setStatusNotification({ message: result.message || 'সার্ভিস বন্ধ করতে সমস্যা দেখা দিয়েছে।', type: 'error' });
    }
  };

  // ৬. পিন যাচাইকরণ
  const handlePinSubmit = async () => {
    if (pinInput.length !== 4) {
      setPinError('দয়া করে ৪ সংখ্যার সঠিক পিন দিন।');
      return;
    }

    setIsVerifyingPin(true);
    try {
      const isValid = await verifyPin(pinInput, settings.pinHash);
      if (isValid) {
        await executeStop();
      } else {
        setPinError('ভুল পিন কোড! পুনরায় চেষ্টা করুন।');
        setPinInput('');
        soundGenerator.playBeep(380, 250);
      }
    } finally {
      setIsVerifyingPin(false);
    }
  };

  const handleKeypadPress = (digit: string) => {
    if (pinInput.length < 4) {
      setPinInput(prev => prev + digit);
      setPinError(null);
    }
  };

  // ৭. পিন পরিবর্তন হ্যান্ডলার
  const handleChangePinSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setChangePinError(null);
    setChangePinSuccess(null);

    if (newPinInput !== confirmPinInput) {
      setChangePinError('নতুন পিন এবং নিশ্চিতকরণ পিন মেলেনি।');
      return;
    }

    const res = await changePin(currentPinInput, newPinInput, settings.pinHash);
    if (res.success && res.newHash) {
      const updated = { ...settings, pinHash: res.newHash };
      setSettings(updated);
      saveLocalSettings(updated);
      setChangePinSuccess('পিন কোড সফলভাবে পরিবর্তন করা হয়েছে!');
      setTimeout(() => {
        setIsChangePinModalOpen(false);
        setCurrentPinInput('');
        setNewPinInput('');
        setConfirmPinInput('');
        setChangePinSuccess(null);
      }, 1500);
    } else {
      setChangePinError(res.error || 'পিন পরিবর্তন ব্যর্থ হয়েছে।');
    }
  };

  // পিন ডিফল্টে রিসেট (শুধুমাত্র IDLE অবস্থায় সম্ভব)
  const handleResetPinToDefault = () => {
    if (alarmState !== 'IDLE') {
      setStatusNotification({ message: 'অ্যালার্ম সক্রিয় অবস্থায় পিন রিসেট করা সম্ভব নয়।', type: 'error' });
      return;
    }
    const defaultHash = getDefaultPinHash();
    const updated = { ...settings, pinHash: defaultHash };
    setSettings(updated);
    saveLocalSettings(updated);
    setStatusNotification({ message: 'পিন কোড সফলভাবে ডিফল্ট (1234)-এ রিসেট করা হয়েছে।', type: 'success' });
  };

  // ৮. সেটিংস আপডেট হেল্পার
  const updateSetting = <K extends keyof AppSettings>(key: K, value: AppSettings[K]) => {
    const updated = { ...settings, [key]: value };
    setSettings(updated);
    saveLocalSettings(updated);
  };

  // ৯. ব্রাউজার মোশন টেস্ট
  const handleTriggerBrowserMotionTest = () => {
    if (alarmState === 'ARMED') {
      setAlarmState('ALARMING');
      soundGenerator.startAlarm(settings.alarmTone, settings.volumeLevel);
      setStatusNotification({ message: 'সতর্কতা: সিমুলেটেড মোশন টেস্ট ট্রিগার হয়েছে!', type: 'error' });
    }
  };

  // ১০. সাউন্ড টেস্ট
  const handleToggleSoundTest = () => {
    if (isTestSoundActive) {
      soundGenerator.stopAlarm();
      setIsTestSoundActive(false);
    } else {
      soundGenerator.startAlarm(settings.alarmTone, settings.volumeLevel);
      setIsTestSoundActive(true);
    }
  };

  // ১১. অফিসিয়াল গিটহাব রিলিজ থেকে ইন-অ্যাপ আপডেট নিরীক্ষা
  const handleCheckForUpdate = async () => {
    setIsCheckingUpdate(true);
    try {
      const result = await checkForAppUpdate();
      setUpdateResult(result);

      if (!result.hasUpdate && !result.errorMessage) {
        setStatusNotification({
          message: `আপনার অ্যাপটি আপ-টু-ডেট রয়েছে (সর্বশেষ সংস্করণ v${result.latestVersion} চলমান)।`,
          type: 'success',
        });
      } else if (result.errorMessage) {
        setStatusNotification({
          message: result.errorMessage,
          type: 'info',
        });
      }
    } catch {
      setStatusNotification({
        message: 'আপডেট সার্ভারের সাথে সংযোগ করা সম্ভব হয়নি।',
        type: 'error',
      });
    } finally {
      setIsCheckingUpdate(false);
    }
  };

  // ১২. এপিকে অ্যাসেট ডাউনলোড শুরু
  const handleDownloadApk = async (url: string) => {
    await nativeBridge.openExternalUrl(url);
  };


  return (
    <div className="min-h-screen bg-[#070d1e] text-slate-100 flex flex-col justify-between selection:bg-blue-600 selection:text-white font-sans relative overflow-x-hidden">
      
      {/* ব্যাকগ্রাউন্ড অ্যারোরা ও গ্লাস ইফেক্ট */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-32 -left-32 w-96 h-96 bg-blue-600/15 rounded-full blur-[100px]" />
        <div className="absolute top-1/2 -right-32 w-80 h-80 bg-orange-600/10 rounded-full blur-[100px]" />
        <div className="absolute -bottom-32 left-1/4 w-96 h-96 bg-slate-800/20 rounded-full blur-[100px]" />
      </div>

      {/* মোবাইল সেন্টারড কন্টেইনার */}
      <div className="w-full max-w-md mx-auto flex-1 flex flex-col bg-slate-950/60 backdrop-blur-2xl border-x border-slate-800/60 shadow-2xl relative z-10">
        
        {/* প্রিমিয়াম টপ বার */}
        <header className="sticky top-0 z-30 flex items-center justify-between px-5 py-3.5 bg-slate-950/80 backdrop-blur-md border-b border-slate-800/70">
          <div className="flex items-center gap-3">
            <div className="relative">
              <img 
                src="/assets/aistudio/file_0000000024988230b726bfa0c89e61a7_7098c100.png" 
                alt="Alert Me লোগো" 
                className="w-10 h-10 rounded-xl object-contain shadow-md bg-white/95 p-0.5 border border-white/20"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-base font-bold tracking-tight text-white leading-none">Alert Me</h1>
                <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-blue-500/15 text-blue-400 border border-blue-500/20">
                  {isAndroidNative ? 'অ্যান্ড্রয়েড' : 'ওয়েব'}
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">অফলাইন অ্যান্টি-থেফট মোশন অ্যালার্ম</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-medium text-slate-400">
              {alarmState === 'IDLE' && 'নিষ্ক্রিয়'}
              {alarmState === 'ARMING' && 'প্রস্তুতি চলছে'}
              {alarmState === 'ARMED' && 'সুরক্ষিত'}
              {alarmState === 'ALARMING' && 'অ্যালার্ম বাজছে'}
              {alarmState === 'STOPPING' && 'বন্ধ হচ্ছে'}
            </span>
          </div>
        </header>

        {/* প্রধান কনটেন্ট স্ক্রোল এরিয়া */}
        <main className="flex-1 p-5 space-y-5 overflow-y-auto pb-24">
          
          {/* ট্যাব নেভিগেশন বার */}
          <nav className="grid grid-cols-3 gap-1 p-1 bg-slate-900/80 backdrop-blur-md rounded-xl border border-slate-800/80 shadow-inner">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`py-2 px-3 text-xs font-medium rounded-lg transition-all min-h-[44px] flex items-center justify-center gap-1.5 ${
                activeTab === 'dashboard' 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30 font-semibold' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldCheck className="w-4 h-4 shrink-0" />
              <span>ড্যাশবোর্ড</span>
            </button>
            <button
              onClick={() => setActiveTab('settings')}
              className={`py-2 px-3 text-xs font-medium rounded-lg transition-all min-h-[44px] flex items-center justify-center gap-1.5 ${
                activeTab === 'settings' 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30 font-semibold' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Sliders className="w-4 h-4 shrink-0" />
              <span>সেটিংস</span>
            </button>
            <button
              onClick={() => setActiveTab('audit')}
              className={`py-2 px-3 text-xs font-medium rounded-lg transition-all min-h-[44px] flex items-center justify-center gap-1.5 ${
                activeTab === 'audit' 
                  ? 'bg-blue-600 text-white shadow-md shadow-blue-900/30 font-semibold' 
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <SettingsIcon className="w-4 h-4 shrink-0" />
              <span>নিরাপত্তা</span>
            </button>
          </nav>

          {/* সিস্টেম স্ট্যাটাস বার্তার প্রদর্শন */}
          {statusNotification && (
            <div className={`p-3.5 rounded-xl border text-xs flex items-center justify-between gap-3 animate-in fade-in transition-all ${
              statusNotification.type === 'error'
                ? 'bg-rose-950/40 border-rose-500/30 text-rose-300'
                : statusNotification.type === 'success'
                ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-300'
                : 'bg-blue-950/40 border-blue-500/30 text-blue-300'
            }`}>
              <div className="flex items-center gap-2">
                {statusNotification.type === 'error' && <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />}
                {statusNotification.type === 'success' && <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />}
                {statusNotification.type === 'info' && <Bell className="w-4 h-4 shrink-0 text-blue-400" />}
                <span>{statusNotification.message}</span>
              </div>
              <button 
                onClick={() => setStatusNotification(null)}
                className="p-1 rounded text-slate-400 hover:text-white"
                aria-label="বার্তা বন্ধ করুন"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* হার্ডওয়্যার সমস্যা বা পারমিশন সতর্কতা ব্যানার */}
          {isAndroidNative && !hasNotificationPerm && (
            <div className="p-4 rounded-xl bg-orange-950/30 border border-orange-500/30 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-semibold text-orange-400">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>নোটিফিকেশন অনুমতি প্রয়োজন (Android 13+)</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                লক স্ক্রিন এবং ব্যাকগ্রাউন্ডে স্থায়ী ফোরগ্রাউন্ড সার্ভিস সচল রাখতে নোটিফিকেশন অনুমতি আবশ্যক।
              </p>
              <button
                onClick={handleRequestNotificationPerm}
                className="min-h-[44px] px-3.5 py-2 rounded-lg bg-orange-600 hover:bg-orange-500 text-white text-xs font-medium transition-colors"
              >
                অনুমতি প্রদান করুন
              </button>
            </div>
          )}

          {!hasAccelerometer && (
            <div className="p-4 rounded-xl bg-rose-950/30 border border-rose-500/30 space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-semibold text-rose-400">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>অ্যাক্সিলারোমিটার সেন্সর অনুপস্থিত</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                ডিভাইসে মোশন ট্র্যাকিং সেন্সর শনাক্ত করা যায়নি। মোশন অ্যালার্ম কাজ নাও করতে পারে।
              </p>
            </div>
          )}

          {/* ট্যাব ১: ড্যাশবোর্ড */}
          {activeTab === 'dashboard' && (
            <div className="space-y-5">
              
              {/* কেন্দ্রীয় স্টেট ড্যাশবোর্ড কার্ড (Glassmorphism) */}
              <div className={`p-6 rounded-3xl border text-center transition-all shadow-xl relative overflow-hidden backdrop-blur-xl ${
                alarmState === 'ALARMING'
                  ? 'bg-rose-950/40 border-rose-500/60 ring-2 ring-rose-500/40 shadow-rose-950/50'
                  : alarmState === 'ARMED'
                  ? 'bg-gradient-to-b from-blue-950/40 to-slate-900/60 border-blue-500/40 shadow-blue-950/30'
                  : alarmState === 'ARMING'
                  ? 'bg-gradient-to-b from-orange-950/30 to-slate-900/60 border-orange-500/40 shadow-orange-950/20'
                  : 'bg-slate-900/60 border-slate-800/80 shadow-black/40'
              }`}>
                
                {/* বড় ভিজ্যুয়াল আইকন ডোমেন */}
                <div className={`inline-flex p-6 rounded-full mx-auto mb-4 transition-all ${
                  alarmState === 'ALARMING'
                    ? 'bg-rose-600 text-white animate-pulse shadow-lg shadow-rose-600/50'
                    : alarmState === 'ARMED'
                    ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30 shadow-lg shadow-blue-500/20'
                    : alarmState === 'ARMING'
                    ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                    : 'bg-slate-800/60 text-slate-400 border border-slate-700/50'
                }`}>
                  {alarmState === 'ALARMING' && <AlertTriangle className="w-16 h-16" />}
                  {alarmState === 'ARMED' && <ShieldCheck className="w-16 h-16" />}
                  {alarmState === 'ARMING' && <RotateCcw className="w-16 h-16 animate-spin" />}
                  {alarmState === 'IDLE' && <ShieldOff className="w-16 h-16" />}
                  {alarmState === 'STOPPING' && <RotateCcw className="w-16 h-16 animate-spin" />}
                </div>

                {/* অবস্থা ও নির্দেশিকা */}
                <h2 className="text-xl font-bold text-white tracking-tight">
                  {alarmState === 'IDLE' && 'অ্যালার্ম বন্ধ (IDLE)'}
                  {alarmState === 'ARMING' && `প্রস্তুতি চলছে: ${countdown} সেকেন্ড`}
                  {alarmState === 'ARMED' && 'ডিভাইস সুরক্ষিত (ARMED)'}
                  {alarmState === 'ALARMING' && 'মোশন শনাক্ত হয়েছে! সাইরেন বাজছে!'}
                  {alarmState === 'STOPPING' && 'বন্ধ ও রিসেট করা হচ্ছে...'}
                </h2>

                <p className="text-xs text-slate-300 mt-2 max-w-xs mx-auto leading-relaxed">
                  {alarmState === 'IDLE' && 'ফোনটি টেবিল বা সমতলে স্থির রেখে নিচের বাটনে চাপ দিন।'}
                  {alarmState === 'ARMING' && 'কাউন্টডাউন শেষ হওয়ার আগে ফোনটি সমতলে রেখে দিন।'}
                  {alarmState === 'ARMED' && 'মোশন সেন্সর সক্রিয়। ফোন স্পর্শ বা স্থানান্তরিত হলে উচ্চ শব্দে সাইরেন বাজবে।'}
                  {alarmState === 'ALARMING' && 'সাইরেন ও ভাইব্রেশন বন্ধ করতে ৪-সংখ্যার পিন প্রদান করুন।'}
                  {alarmState === 'STOPPING' && 'সেন্সর এবং অডিও রিসোর্স ক্লিনআপ হচ্ছে।'}
                </p>

                {/* প্রধান অ্যাকশন কন্ট্রোল বাটন */}
                <div className="mt-6 pt-5 border-t border-slate-800/80">
                  {alarmState === 'IDLE' && (
                    <button
                      onClick={handleStartArming}
                      className="w-full min-h-[52px] py-3.5 px-6 rounded-2xl bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 active:scale-[0.98] text-white font-bold text-sm shadow-xl shadow-blue-900/40 transition-all flex items-center justify-center gap-2.5"
                    >
                      <Lock className="w-5 h-5" />
                      <span>অ্যালার্ম আর্ম করুন ({settings.armDelaySeconds} সে. বিলম্ব)</span>
                    </button>
                  )}

                  {alarmState === 'ARMING' && (
                    <button
                      onClick={handleCancelArming}
                      className="w-full min-h-[50px] py-3.5 px-6 rounded-2xl bg-slate-800 hover:bg-slate-700 active:scale-[0.98] text-slate-200 font-semibold text-sm transition-all flex items-center justify-center gap-2 border border-slate-700"
                    >
                      <X className="w-4 h-4" />
                      <span>প্রস্তুতি বাতিল করুন</span>
                    </button>
                  )}

                  {(alarmState === 'ARMED' || alarmState === 'ALARMING') && (
                    <div className="space-y-3">
                      <button
                        onClick={handleRequestStop}
                        className={`w-full min-h-[52px] py-3.5 px-6 rounded-2xl font-bold text-sm transition-all flex items-center justify-center gap-2.5 active:scale-[0.98] ${
                          alarmState === 'ALARMING'
                            ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-xl shadow-rose-900/60'
                            : 'bg-orange-600 hover:bg-orange-500 text-white shadow-xl shadow-orange-950/40'
                        }`}
                      >
                        <Unlock className="w-5 h-5" />
                        <span>অ্যালার্ম বন্ধ করুন {settings.pinProtectionEnabled ? '(পিন আবশ্যক)' : ''}</span>
                      </button>

                      {/* ব্রাউজার মোশন টেস্ট বাটন */}
                      {!isAndroidNative && alarmState === 'ARMED' && (
                        <button
                          onClick={handleTriggerBrowserMotionTest}
                          className="w-full min-h-[44px] py-2 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs text-orange-300 font-medium transition-all"
                        >
                          ব্রাউজার মোশন টেস্ট সিমুলেশন
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>

              {/* সংক্ষেপণ প্যারামিটার স্ট্রিপ */}
              <div className="grid grid-cols-2 gap-3">
                <div className="p-3.5 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80">
                  <span className="text-[11px] text-slate-400 block">সংবেদনশীলতা</span>
                  <span className="text-sm font-semibold text-slate-200 mt-0.5 block">
                    {settings.sensitivity === 'low' && 'কম (3.5 m/s²)'}
                    {settings.sensitivity === 'medium' && 'মাঝারি (1.8 m/s²)'}
                    {settings.sensitivity === 'high' && 'উচ্চ (0.8 m/s²)'}
                  </span>
                </div>
                <div className="p-3.5 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80">
                  <span className="text-[11px] text-slate-400 block">নিরাপত্তা পিন</span>
                  <span className="text-sm font-semibold text-slate-200 mt-0.5 block">
                    {settings.pinProtectionEnabled ? 'সক্রিয় (সুরক্ষিত)' : 'বন্ধ'}
                  </span>
                </div>
              </div>

              {/* অফলাইন সাউন্ড টেস্ট কার্ড */}
              <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-semibold text-slate-200">অডিও সাইরেন পরীক্ষা</h3>
                  <p className="text-[11px] text-slate-400">লোকাল সিন্থেসাইজার শব্দ যাচাই</p>
                </div>
                <button
                  onClick={handleToggleSoundTest}
                  className={`min-h-[44px] px-4 py-2 rounded-xl text-xs font-medium flex items-center gap-2 transition-all active:scale-95 ${
                    isTestSoundActive
                      ? 'bg-rose-600 text-white shadow-md shadow-rose-900/40'
                      : 'bg-slate-800 text-slate-200 border border-slate-700 hover:bg-slate-700'
                  }`}
                >
                  {isTestSoundActive ? (
                    <>
                      <VolumeX className="w-4 h-4" />
                      <span>থামান</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-4 h-4" />
                      <span>শব্দ শুনুন</span>
                    </>
                  )}
                </button>
              </div>

              {/* প্ল্যাটফর্ম সীমাবদ্ধতা স্পষ্টীকরণ নোটিশ */}
              {!isAndroidNative && (
                <div className="p-4 rounded-2xl bg-blue-950/20 border border-blue-500/20 space-y-2">
                  <div className="flex items-center gap-2 text-xs font-semibold text-blue-400">
                    <Smartphone className="w-4 h-4 shrink-0" />
                    <span>ব্রাউজার প্রিভিউ পরিবেশ নোটিশ</span>
                  </div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    ব্রাউজারে স্ক্রিন অফ থাকাকালীন সিস্টেম-লেভেল ব্যাকগ্রাউন্ড ফোরগ্রাউন্ড সার্ভিস চলে না। পূর্ণাঙ্গ ব্যাকগ্রাউন্ড সুরক্ষার জন্য প্রস্তুতকৃত কোটলিন ফোরগ্রাউন্ড সার্ভিসটি অ্যান্ড্রয়েড APK-তে সক্রিয় থাকবে।
                  </p>
                </div>
              )}

            </div>
          )}

          {/* ট্যাব ২: কনফিগারেশন সেটিংস */}
          {activeTab === 'settings' && (
            <div className="space-y-5">
              <div className="border-b border-slate-800/80 pb-2.5">
                <h2 className="text-sm font-bold text-white">অ্যালার্ম ও সেন্সর কনফিগারেশন</h2>
                <p className="text-xs text-slate-400 mt-0.5">সব সেটিংস ডিভাইসের নিজস্ব মেমরিতে তাৎক্ষণিক সংরক্ষিত হয়।</p>
              </div>

              {/* ফোন রাখার বিলম্ব (Arm Delay) */}
              <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 space-y-2.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">আর্ম কাউন্টডাউন বিলম্ব</span>
                  <span className="text-blue-400 font-mono font-semibold">{settings.armDelaySeconds} সেকেন্ড</span>
                </div>
                <div className="grid grid-cols-4 gap-2 pt-1">
                  {[3, 5, 10, 15].map((sec) => (
                    <button
                      key={sec}
                      onClick={() => updateSetting('armDelaySeconds', sec)}
                      className={`min-h-[44px] rounded-xl text-xs font-medium transition-colors ${
                        settings.armDelaySeconds === sec
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {sec} সে.
                    </button>
                  ))}
                </div>
              </div>

              {/* সংবেদনশীলতা (Sensitivity) */}
              <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 space-y-2.5">
                <div className="flex justify-between text-xs">
                  <span className="text-slate-300 font-medium">মোশন সংবেদনশীলতা</span>
                  <span className="text-blue-400 font-mono text-[11px]">
                    থ্রেশহোল্ড: {settings.motionThreshold} m/s²
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {(['low', 'medium', 'high'] as MotionSensitivity[]).map((lvl) => (
                    <button
                      key={lvl}
                      onClick={() => updateSetting('sensitivity', lvl)}
                      className={`min-h-[44px] rounded-xl text-xs font-medium transition-colors ${
                        settings.sensitivity === lvl
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {lvl === 'low' && 'কম (3.5)'}
                      {lvl === 'medium' && 'মাঝারি (1.8)'}
                      {lvl === 'high' && 'উচ্চ (0.8)'}
                    </button>
                  ))}
                </div>
              </div>

              {/* সাউন্ড টোন নির্বাচন */}
              <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 space-y-2.5">
                <span className="text-xs text-slate-300 font-medium block">অ্যালার্ম সাউন্ড টোন</span>
                <div className="grid grid-cols-3 gap-2 pt-1">
                  {(['siren', 'police', 'radar'] as AlarmToneType[]).map((tone) => (
                    <button
                      key={tone}
                      onClick={() => updateSetting('alarmTone', tone)}
                      className={`min-h-[44px] rounded-xl text-xs font-medium transition-colors ${
                        settings.alarmTone === tone
                          ? 'bg-blue-600 text-white shadow-sm'
                          : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {tone === 'siren' && 'সাইরেন'}
                      {tone === 'police' && 'পুলিশ'}
                      {tone === 'radar' && 'রাডার'}
                    </button>
                  ))}
                </div>
              </div>

              {/* ভাইব্রেশন টগল */}
              <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 flex items-center justify-between">
                <div>
                  <span className="text-xs font-medium text-slate-200 block">ভাইব্রেশন অ্যালার্ট</span>
                  <span className="text-[11px] text-slate-400">অ্যালার্ম বাজার সময়ে কম্পন সংকেত</span>
                </div>
                <button
                  onClick={() => updateSetting('vibrationEnabled', !settings.vibrationEnabled)}
                  className={`w-12 h-7 rounded-full p-1 transition-colors min-w-[48px] min-h-[44px] flex items-center ${
                    settings.vibrationEnabled ? 'bg-blue-600 justify-end' : 'bg-slate-700 justify-start'
                  }`}
                  aria-label="ভাইব্রেশন টগল"
                >
                  <div className="w-5 h-5 rounded-full bg-white shadow-sm" />
                </button>
              </div>

              {/* পিন সুরক্ষা অপশন ও পরিবর্তন বাটন */}
              <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-medium text-slate-200 block">অ্যালার্ম বন্ধে পিন সুরক্ষা</span>
                    <span className="text-[11px] text-slate-400">অননুমোদিত ব্যক্তি দ্বারা বন্ধ রোধ</span>
                  </div>
                  <button
                    onClick={() => updateSetting('pinProtectionEnabled', !settings.pinProtectionEnabled)}
                    className={`w-12 h-7 rounded-full p-1 transition-colors min-w-[48px] min-h-[44px] flex items-center ${
                      settings.pinProtectionEnabled ? 'bg-blue-600 justify-end' : 'bg-slate-700 justify-start'
                    }`}
                    aria-label="পিন সুরক্ষা টগল"
                  >
                    <div className="w-5 h-5 rounded-full bg-white shadow-sm" />
                  </button>
                </div>

                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-3">
                  <button
                    onClick={() => {
                      setChangePinError(null);
                      setChangePinSuccess(null);
                      setCurrentPinInput('');
                      setNewPinInput('');
                      setConfirmPinInput('');
                      setIsChangePinModalOpen(true);
                    }}
                    className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-200 flex items-center gap-1.5 transition-colors"
                  >
                    <KeyRound className="w-4 h-4 text-blue-400" />
                    <span>পিন পরিবর্তন করুন</span>
                  </button>

                  <button
                    onClick={handleResetPinToDefault}
                    disabled={alarmState !== 'IDLE'}
                    className="min-h-[44px] px-3 py-2 rounded-xl text-[11px] text-slate-400 hover:text-slate-200 disabled:opacity-40 transition-colors"
                  >
                    ডিফল্ট (1234) রিসেট
                  </button>
                </div>
              </div>

              {/* অ্যাপ সংস্করণ ও অফিসিয়াল আপডেট কার্ড */}
              <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 space-y-3.5">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs font-bold text-white flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-orange-400" />
                      <span>অ্যাপ সংস্করণ ও আপডেট</span>
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      ইনস্টল করা সংস্করণ: <span className="font-mono text-blue-400 font-semibold">v{APP_CONFIG.versionName}</span>
                    </p>
                  </div>

                  <button
                    onClick={handleCheckForUpdate}
                    disabled={isCheckingUpdate}
                    className="min-h-[44px] px-3.5 py-2 rounded-xl bg-blue-600/90 hover:bg-blue-600 active:scale-95 disabled:opacity-50 text-xs font-semibold text-white flex items-center gap-1.5 transition-all shadow-md shadow-blue-900/30"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isCheckingUpdate ? 'animate-spin' : ''}`} />
                    <span>{isCheckingUpdate ? 'পরীক্ষা হচ্ছে...' : 'আপডেট পরীক্ষা'}</span>
                  </button>
                </div>

                {/* আপডেট পরীক্ষার ফলাফল প্রদর্শন */}
                {updateResult && updateResult.hasUpdate && (
                  <div className="p-4 rounded-xl bg-gradient-to-b from-blue-950/40 to-slate-900/80 border border-blue-500/40 space-y-3 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-orange-400 flex items-center gap-1">
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>নতুন সংস্করণ উপলব্ধ: v{updateResult.latestVersion}</span>
                      </span>
                      {updateResult.publishedAt && (
                        <span className="text-[10px] text-slate-400">{updateResult.publishedAt}</span>
                      )}
                    </div>

                    {updateResult.releaseTitle && (
                      <p className="font-semibold text-slate-200 text-xs">{updateResult.releaseTitle}</p>
                    )}

                    {updateResult.releaseNotes && (
                      <div className="p-2.5 rounded-lg bg-slate-950/60 border border-slate-800/80 max-h-24 overflow-y-auto text-[11px] text-slate-300 whitespace-pre-line leading-relaxed">
                        {updateResult.releaseNotes}
                      </div>
                    )}

                    {updateResult.apkAsset ? (
                      <div className="space-y-2 pt-1">
                        <button
                          onClick={() => handleDownloadApk(updateResult.apkAsset!.downloadUrl)}
                          className="w-full min-h-[46px] py-2.5 px-4 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 active:scale-[0.98] text-white font-bold text-xs shadow-lg shadow-orange-950/40 transition-all flex items-center justify-center gap-2"
                        >
                          <Download className="w-4 h-4" />
                          <span>নতুন সংস্করণ ডাউনলোড ও ইনস্টল করুন ({updateResult.apkAsset.sizeFormatted})</span>
                        </button>
                        <p className="text-[10px] text-slate-400 text-center leading-tight">
                          ইনস্টলের সময় Android 'Install unknown apps' অনুমোদন চাইতে পারে। পূর্বের অ্যাপ আনইনস্টল করার প্রয়োজন নেই, ডেটা সংরক্ষিত থাকবে।
                        </p>
                      </div>
                    ) : (
                      <div className="pt-1">
                        <button
                          onClick={() => handleDownloadApk(updateResult.htmlUrl || APP_CONFIG.github.releasesPageUrl)}
                          className="w-full min-h-[44px] py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                        >
                          <ExternalLink className="w-4 h-4 text-blue-400" />
                          <span>গিটহাব রিলিজ পেজে দেখুন</span>
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {updateResult && !updateResult.hasUpdate && !updateResult.errorMessage && (
                  <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/20 text-xs text-emerald-300 flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>আপনার অ্যাপটি আপ-টু-ডেট রয়েছে। আপনি সর্বশেষ সংস্করণ ব্যবহার করছেন।</span>
                  </div>
                )}

                {updateResult && updateResult.errorMessage && (
                  <div className="p-3 rounded-xl bg-slate-800/50 border border-slate-700 text-xs text-slate-300 flex items-center justify-between">
                    <span>{updateResult.errorMessage}</span>
                    <button
                      onClick={handleCheckForUpdate}
                      className="text-[11px] text-blue-400 hover:underline shrink-0 ml-2"
                    >
                      পুনরায় চেষ্টা
                    </button>
                  </div>
                )}
              </div>

            </div>
          )}


          {/* ট্যাব ৩: নিরাপত্তা ও টেকনিক্যাল অডিট */}
          {activeTab === 'audit' && (
            <div className="space-y-4 text-xs">
              <div className="border-b border-slate-800/80 pb-2.5">
                <h2 className="text-sm font-bold text-white">নিরাপত্তা ও সিস্টেম আর্কিটেকচার অডিট</h2>
                <p className="text-slate-400 mt-0.5">অফলাইন সুরক্ষা মডেল ও পারমিশন বাস্তবায়ন</p>
              </div>

              {/* অফলাইন ও ডাটা নিরাপত্তা অঙ্গীকার */}
              <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 space-y-2">
                <h3 className="font-semibold text-slate-200 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>১০০% অফলাইন নিরাপত্তা মডেল</span>
                </h3>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  Alert Me কোনো ক্লাউড ডাটাবেজ, লগইন অ্যাকাউন্ট, ইউজার ট্র্যাকিং বা ব্যাকএন্ড সার্ভার ব্যবহার করে না। আপনার সেটিংস এবং পিন কোড শুধুমাত্র ডিভাইসের নিজস্ব সংরক্ষিত মেমরিতে থাকে।
                </p>
              </div>

              {/* অ্যান্ড্রয়েড ফোরগ্রাউন্ড সার্ভিস ও পারমিশন স্ট্যাটাস */}
              <div className="p-4 rounded-2xl bg-slate-900/60 backdrop-blur-md border border-slate-800/80 space-y-2.5">
                <h3 className="font-semibold text-slate-200">অ্যান্ড্রয়েড ফোরগ্রাউন্ড সার্ভিস আর্কিটেকচার</h3>
                <ul className="space-y-1.5 text-slate-300 text-[11px]">
                  <li>• <strong>Service Type</strong>: <code className="text-blue-400 font-mono">specialUse</code> (অ্যান্টি-থেফট মোশন সেন্সর ব্যবহারের জন্য যথার্থ)</li>
                  <li>• <strong>Subtype Declaration</strong>: <code className="text-blue-400 font-mono">Anti-theft motion detection and security alarm</code></li>
                  <li>• <strong>Permissions</strong>: <code className="text-blue-400 font-mono">FOREGROUND_SERVICE</code>, <code className="text-blue-400 font-mono">FOREGROUND_SERVICE_SPECIAL_USE</code>, <code className="text-blue-400 font-mono">POST_NOTIFICATIONS</code></li>
                  <li>• <strong>ফলস-ট্রিগার প্রতিরোধ</strong>: অ্যাক্সিলারোমিটার ক্যালিব্রেশন এবং ৪০০ms উইন্ডোতে পরপর নিশ্চিত সংকেত যাচাই।</li>
                </ul>
              </div>

              {/* ওএস স্তরের সীমাবদ্ধতা */}
              <div className="p-4 rounded-2xl bg-orange-950/20 border border-orange-500/20 text-orange-200/90 space-y-2">
                <div className="flex items-center gap-2 font-semibold text-orange-300">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>বাস্তবসম্মত ওএস সীমাবদ্ধতা</span>
                </div>
                <p className="text-[11px] leading-relaxed">
                  অ্যান্ড্রয়েডের ওএস সিকিউরিটি পলিসি অনুযায়ী কোনো সাধারণ থার্ড-পার্টি অ্যাপ ফোন হার্ড-পাওয়ার অফ রোধ করতে পারে না বা সিস্টেম ফোর্স-স্টপ প্রতিরোধ করতে পারে না। Alert Me এর কাজ হল কেউ ফোন স্পর্শ বা উঠিয়ে নেওয়ার মুহূর্তে তাৎক্ষণিক উচ্চ শব্দে সাইরেন বাজিয়ে আপনাকে ও আশেপাশের মানুষকে সতর্ক করা।
                </p>
              </div>
            </div>
          )}

        </main>

        {/* ফুটার */}
        <footer className="p-3 border-t border-slate-800/80 bg-slate-950/90 text-center">
          <p className="text-[11px] text-slate-400">Alert Me • ১০০% অফলাইন ও ব্যক্তিগত ডেটা নিরাপদ</p>
        </footer>

      </div>

      {/* পিন আনলক মডাল (শুধুমাত্র অ্যালার্ম বন্ধ করার সময় প্রদর্শিত) */}
      {isPinModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border-t sm:border border-slate-800 rounded-t-3xl sm:rounded-2xl p-6 space-y-5 shadow-2xl">
            
            <div className="text-center space-y-1">
              <div className="w-12 h-12 rounded-full bg-blue-600/20 text-blue-400 flex items-center justify-center mx-auto mb-2 border border-blue-500/30">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-white">অ্যালার্ম বন্ধ করতে পিন দিন</h3>
              <p className="text-xs text-slate-400">ডিফল্ট পিন কোড: 1234</p>
            </div>

            {/* ৪-সংখ্যার ডট ডিসপ্লে */}
            <div className="flex justify-center items-center gap-3 py-2">
              {[0, 1, 2, 3].map((idx) => (
                <div
                  key={idx}
                  className={`w-4 h-4 rounded-full border transition-all ${
                    idx < pinInput.length
                      ? 'bg-blue-500 border-blue-400 scale-110 shadow-sm shadow-blue-500/50'
                      : 'bg-slate-800 border-slate-700'
                  }`}
                />
              ))}
            </div>

            {/* ত্রুটি বার্তা */}
            {pinError && (
              <p className="text-xs text-rose-400 text-center font-medium">{pinError}</p>
            )}

            {/* অন-স্ক্রিন নিউমেরিক কিপ্যাড (টাস্ক টার্গেট >= ৫০ পিক্সেল) */}
            <div className="grid grid-cols-3 gap-2 pt-2">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                <button
                  key={digit}
                  onClick={() => handleKeypadPress(digit)}
                  className="min-h-[50px] rounded-xl bg-slate-800/80 hover:bg-slate-700 active:bg-blue-600 text-lg font-semibold text-white transition-colors flex items-center justify-center"
                >
                  {digit}
                </button>
              ))}
              <button
                onClick={() => setPinInput('')}
                className="min-h-[50px] rounded-xl bg-slate-800/40 hover:bg-slate-800 text-xs text-slate-400 font-medium active:scale-95 transition-all flex items-center justify-center"
              >
                মুছুন
              </button>
              <button
                onClick={() => handleKeypadPress('0')}
                className="min-h-[50px] rounded-xl bg-slate-800/80 hover:bg-slate-700 active:bg-blue-600 text-lg font-semibold text-white transition-colors flex items-center justify-center"
              >
                0
              </button>
              <button
                onClick={handlePinSubmit}
                disabled={isVerifyingPin || pinInput.length !== 4}
                className="min-h-[50px] rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-white font-medium text-xs active:scale-95 transition-all flex items-center justify-center gap-1 shadow-md shadow-blue-900/30"
              >
                {isVerifyingPin ? <RotateCcw className="w-4 h-4 animate-spin" /> : <Check className="w-5 h-5" />}
              </button>
            </div>

            <div className="pt-2 text-center">
              <button
                onClick={() => setIsPinModalOpen(false)}
                className="text-xs text-slate-400 hover:text-slate-200 py-2 px-4"
              >
                ফিরে যান
              </button>
            </div>

            <p className="text-[10px] text-slate-400 text-center leading-tight">
              বিজ্ঞপ্তি: লোকাল অ্যাপ পিন কেবল অসতর্ক স্পর্শ বন্ধ করতে ব্যবহৃত হয়। এটি ডিভাইস ওএস লক বা হার্ডওয়্যার এনক্রিপশন নয়।
            </p>

          </div>
        </div>
      )}

      {/* পিন পরিবর্তন মডাল (সেটিংস ট্যাব থেকে ওপেন হয়) */}
      {isChangePinModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in">
          <div className="w-full max-w-sm bg-slate-900 border-t sm:border border-slate-800 rounded-t-3xl sm:rounded-2xl p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-blue-400" />
                <span>পিন কোড পরিবর্তন করুন</span>
              </h3>
              <button
                onClick={() => setIsChangePinModalOpen(false)}
                className="text-slate-400 hover:text-white p-1"
                aria-label="বন্ধ করুন"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleChangePinSubmit} className="space-y-3.5">
              <div>
                <label className="text-[11px] font-medium text-slate-300 block mb-1">বর্তমান পিন (ডিফল্ট: 1234)</label>
                <input
                  type="password"
                  maxLength={4}
                  value={currentPinInput}
                  onChange={(e) => setCurrentPinInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="৪ সংখ্যা"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-blue-500 outline-none text-center tracking-widest"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-medium text-slate-300 block mb-1">নতুন ৪-সংখ্যার পিন</label>
                <input
                  type="password"
                  maxLength={4}
                  value={newPinInput}
                  onChange={(e) => setNewPinInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="নতুন ৪ সংখ্যা"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-blue-500 outline-none text-center tracking-widest"
                  required
                />
              </div>

              <div>
                <label className="text-[11px] font-medium text-slate-300 block mb-1">নতুন পিন নিশ্চিত করুন</label>
                <input
                  type="password"
                  maxLength={4}
                  value={confirmPinInput}
                  onChange={(e) => setConfirmPinInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="পুনরায় টাইপ করুন"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-white text-sm focus:border-blue-500 outline-none text-center tracking-widest"
                  required
                />
              </div>

              {changePinError && (
                <p className="text-xs text-rose-400 font-medium">{changePinError}</p>
              )}

              {changePinSuccess && (
                <p className="text-xs text-emerald-400 font-medium">{changePinSuccess}</p>
              )}

              <div className="pt-2 flex gap-2">
                <button
                  type="button"
                  onClick={() => setIsChangePinModalOpen(false)}
                  className="flex-1 min-h-[44px] py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-medium text-slate-300 transition-colors"
                >
                  বাতিল
                </button>
                <button
                  type="submit"
                  disabled={newPinInput.length !== 4 || confirmPinInput.length !== 4}
                  className="flex-1 min-h-[44px] py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 disabled:opacity-40 text-xs font-semibold text-white transition-colors"
                >
                  সংরক্ষণ করুন
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
