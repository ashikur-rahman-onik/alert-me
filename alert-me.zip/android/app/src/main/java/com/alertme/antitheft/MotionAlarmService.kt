package com.alertme.antitheft

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import kotlin.math.sqrt

/**
 * অ্যান্টি-থেফট মোশন অ্যালার্ম ব্যাকগ্রাউন্ড ফোরগ্রাউন্ড সার্ভিস
 */
class MotionAlarmService : Service(), SensorEventListener {

    companion object {
        const val CHANNEL_ID = "alert_me_motion_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.alertme.antitheft.ACTION_START"
        const val ACTION_STOP = "com.alertme.antitheft.ACTION_STOP"

        const val EXTRA_THRESHOLD = "extra_threshold"
        const val EXTRA_ARM_DELAY = "extra_arm_delay"
        const val EXTRA_VOLUME = "extra_volume"
        const val EXTRA_VIBRATION = "extra_vibration"

        var currentState: AlarmState = AlarmState.IDLE
            private set

        var stateChangeListener: ((AlarmState, String?) -> Unit)? = null

        private fun updateState(newState: AlarmState, reason: String? = null) {
            currentState = newState
            stateChangeListener?.invoke(newState, reason)
        }
    }

    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null

    private var wakeLock: PowerManager.WakeLock? = null
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null

    private var targetThreshold: Float = 1.8f
    private var armDelaySeconds: Int = 5
    private var targetVolume: Int = 100
    private var isVibrationEnabled: Boolean = true

    private val handler = Handler(Looper.getMainLooper())
    private var armingRunnable: Runnable? = null

    // বেসলাইন ক্যালিব্রেশন এবং ফলস-ট্রিগার ফিল্টারিং ভেরিয়েবল
    private var baselineEstablished = false
    private var baselineSamples = 0
    private var baseAccX = 0f
    private var baseAccY = 0f
    private var baseAccZ = 9.8f

    // ফলস পজিটিভ রোধ করতে কনফার্মেশন উইন্ডো
    private var anomalyCount = 0
    private var lastAnomalyTime = 0L
    private val CONFIRMATION_WINDOW_MS = 400L
    private val REQUIRED_ANOMALIES = 2

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = powerManager?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AlertMe::AlarmWakeLock")

        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                targetThreshold = intent.getFloatExtra(EXTRA_THRESHOLD, 1.8f)
                armDelaySeconds = intent.getIntExtra(EXTRA_ARM_DELAY, 5)
                targetVolume = intent.getIntExtra(EXTRA_VOLUME, 100)
                isVibrationEnabled = intent.getBooleanExtra(EXTRA_VIBRATION, true)
                startArmingLifecycle()
            }
            ACTION_STOP -> {
                stopAlarmLifecycle()
            }
        }
        return START_NOT_STICKY
    }

    private fun startArmingLifecycle() {
        if (currentState != AlarmState.IDLE) {
            stopAlarmLifecycle()
        }

        updateState(AlarmState.ARMING, "কাউন্টডাউন শুরু হয়েছে")
        
        val notification = buildNotification("অ্যালার্ম প্রস্তুত হচ্ছে...", "ফোনটি সমতলে রাখুন")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        try {
            wakeLock?.acquire(10 * 60 * 1000L /* ১০ মিনিট সেফগার্ড */)
        } catch (_: Exception) {}

        armingRunnable = Runnable {
            startArmedMonitoring()
        }
        handler.postDelayed(armingRunnable!!, (armDelaySeconds * 1000).toLong())
    }

    private fun startArmedMonitoring() {
        if (currentState != AlarmState.ARMING) return

        baselineEstablished = false
        baselineSamples = 0
        anomalyCount = 0

        val registered = accelerometer?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        } ?: false

        if (registered) {
            updateState(AlarmState.ARMED, "মোশন পর্যবেক্ষণ সক্রিয়")
            updateNotification("ডিভাইস সুরক্ষিত", "মোশন সেন্সর সক্রিয় রয়েছে")
        } else {
            stopAlarmLifecycle()
            updateState(AlarmState.IDLE, "অ্যাক্সিলারোমিটার সেন্সর পাওয়া যায়নি")
        }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null || currentState != AlarmState.ARMED) return

        val x = event.values[0]
        val y = event.values[1]
        val z = event.values[2]

        // প্রথম ৮টি স্যাম্পল থেকে স্থিতিশীল বেসলাইন তৈরি
        if (!baselineEstablished) {
            baseAccX = (baseAccX * baselineSamples + x) / (baselineSamples + 1)
            baseAccY = (baseAccY * baselineSamples + y) / (baselineSamples + 1)
            baseAccZ = (baseAccZ * baselineSamples + z) / (baselineSamples + 1)
            baselineSamples++
            if (baselineSamples >= 8) {
                baselineEstablished = true
            }
            return
        }

        // বেসলাইন থেকে বিচ্যুতির মান (Delta Magnitude)
        val dx = x - baseAccX
        val dy = y - baseAccY
        val dz = z - baseAccZ
        val delta = sqrt((dx * dx + dy * dy + dz * dz).toDouble()).toFloat()

        if (delta > targetThreshold) {
            val now = System.currentTimeMillis()
            if (now - lastAnomalyTime < CONFIRMATION_WINDOW_MS) {
                anomalyCount++
            } else {
                anomalyCount = 1
            }
            lastAnomalyTime = now

            // আকস্মিক একক ভাইব্রেশন বাদ দিয়ে পর পর নিশ্চিত সিগন্যালে অ্যালার্ম বাজানো
            if (anomalyCount >= REQUIRED_ANOMALIES) {
                triggerAlarm()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun triggerAlarm() {
        if (currentState == AlarmState.ALARMING) return
        updateState(AlarmState.ALARMING, "মোশন শনাক্ত হয়েছে!")

        updateNotification("সতর্কতা: মোশন শনাক্ত হয়েছে!", "অবিলম্বে পিন কোড দিয়ে আনলক করুন")

        // অডিও ভলিউম সেট (একবার মাত্র সেট করা হয়, কোনো লুপে নয়)
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            if (audioManager != null) {
                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
                val calculatedVol = (maxVol * (targetVolume / 100.0)).toInt().coerceIn(1, maxVol)
                audioManager.setStreamVolume(AudioManager.STREAM_ALARM, calculatedVol, 0)
            }
        } catch (_: Exception) {}

        // বিল্ট-ইন অফলাইন অ্যালার্ম সাউন্ড প্লেয়ার
        playAlarmAudio()

        // ভাইব্রেশন শুরু
        if (isVibrationEnabled) {
            startVibration()
        }
    }

    private fun playAlarmAudio() {
        try {
            val alertUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(applicationContext, alertUri)
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Exception) {
            // অডিও ব্যর্থ হলে নীরব ফলব্যাক
        }
    }

    private fun startVibration() {
        val pattern = longArrayOf(0, 500, 200, 500, 200, 800)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun stopAlarmLifecycle() {
        updateState(AlarmState.STOPPING, "অ্যালার্ম বন্ধ করা হচ্ছে")

        // টাইমার ও রানাবল বাতিল
        armingRunnable?.let { handler.removeCallbacks(it) }
        armingRunnable = null

        // সেন্সর আনরেজিস্টার
        sensorManager?.unregisterListener(this)

        // অডিও প্লেয়ার বন্ধ ও রিলিজ
        try {
            if (mediaPlayer?.isPlaying == true) {
                mediaPlayer?.stop()
            }
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null

        // ভাইব্রেশন বন্ধ
        try {
            vibrator?.cancel()
        } catch (_: Exception) {}

        // ওয়েক-লক রিলিজ
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {}

        updateState(AlarmState.IDLE, "অ্যালার্ম সম্পূর্ণরূপে নিষ্ক্রিয়")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Alert Me মোশন অ্যালার্ম",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "অ্যান্টি-থেফট সক্রিয় সুরক্ষা নোটিফিকেশন"
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(title: String, text: String): Notification {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun updateNotification(title: String, text: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, buildNotification(title, text))
    }

    override fun onDestroy() {
        stopAlarmLifecycle()
        super.onDestroy()
    }
}
