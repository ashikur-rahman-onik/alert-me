package com.alertme.antitheft;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(AlertMePlugin.class);
        super.onCreate(savedInstanceState);
    }
}
