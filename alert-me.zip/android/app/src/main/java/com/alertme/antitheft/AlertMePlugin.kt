package com.alertme.antitheft

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import com.getcapacitor.annotation.Permission
import com.getcapacitor.annotation.PermissionCallback

@CapacitorPlugin(
    name = "AlertMeNative",
    permissions = [
        Permission(
            alias = "notifications",
            strings = [Manifest.permission.POST_NOTIFICATIONS]
        )
    ]
)
class AlertMePlugin : Plugin() {

    override fun load() {
        super.load()
        // সার্ভিসের স্টেট পরিবর্তনের সাথে ক্যাপাসিটর ইভেন্ট সিঙ্ক রাখা
        MotionAlarmService.stateChangeListener = { state, reason ->
            val ret = JSObject().apply {
                put("state", state.name)
                put("reason", reason ?: "")
                put("timestamp", System.currentTimeMillis())
            }
            notifyListeners("alarmStateChange", ret)
        }
    }

    @PluginMethod
    fun startAlarm(call: PluginCall) {
        val context = context ?: run {
            call.reject("অ্যান্ড্রয়েড কনটেক্সট পাওয়া যায়নি")
            return
        }

        val threshold = call.getDouble("threshold", 1.8).toFloat()
        val armDelay = call.getInt("armDelaySeconds", 5) ?: 5
        val volume = call.getInt("volumeLevel", 100) ?: 100
        val vibration = call.getBoolean("vibrationEnabled", true) ?: true

        val intent = Intent(context, MotionAlarmService::class.java).apply {
            action = MotionAlarmService.ACTION_START
            putExtra(MotionAlarmService.EXTRA_THRESHOLD, threshold)
            putExtra(MotionAlarmService.EXTRA_ARM_DELAY, armDelay)
            putExtra(MotionAlarmService.EXTRA_VOLUME, volume)
            putExtra(MotionAlarmService.EXTRA_VIBRATION, vibration)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }

            val ret = JSObject().apply {
                put("success", true)
                put("state", AlarmState.ARMING.name)
            }
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("ফোরগ্রাউন্ড সার্ভিস চালু করা সম্ভব হয়নি: ${e.message}")
        }
    }

    @PluginMethod
    fun stopAlarm(call: PluginCall) {
        val context = context ?: run {
            call.reject("অ্যান্ড্রয়েড কনটেক্সট পাওয়া যায়নি")
            return
        }

        val intent = Intent(context, MotionAlarmService::class.java).apply {
            action = MotionAlarmService.ACTION_STOP
        }

        try {
            context.startService(intent)
            val ret = JSObject().apply {
                put("success", true)
                put("state", AlarmState.IDLE.name)
            }
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("সার্ভিস বন্ধ করতে ত্রুটি হয়েছে: ${e.message}")
        }
    }

    @PluginMethod
    fun getAlarmState(call: PluginCall) {
        val ret = JSObject().apply {
            put("state", MotionAlarmService.currentState.name)
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun checkPermissions(call: PluginCall) {
        val context = context ?: run {
            call.reject("কনটেক্সট পাওয়া যায়নি")
            return
        }

        val hasNotification = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        val hasAccelerometer = context.packageManager.hasSystemFeature(PackageManager.FEATURE_SENSOR_ACCELEROMETER)

        val ret = JSObject().apply {
            put("hasNotificationPermission", hasNotification)
            put("hasAccelerometer", hasAccelerometer)
            put("canUseFullScreenIntent", true)
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun requestNotificationPermission(call: PluginCall) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (getPermissionState("notifications") != com.getcapacitor.PermissionState.GRANTED) {
                requestPermissionForAlias("notifications", call, "notificationPermCallback")
                return
            }
        }
        val ret = JSObject().apply {
            put("granted", true)
        }
        call.resolve(ret)
    }

    @PermissionCallback
    fun notificationPermCallback(call: PluginCall) {
        val isGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getPermissionState("notifications") == com.getcapacitor.PermissionState.GRANTED
        } else {
            true
        }
        val ret = JSObject().apply {
            put("granted", isGranted)
        }
        call.resolve(ret)
    }

    @PluginMethod
    fun openUrl(call: PluginCall) {
        val url = call.getString("url") ?: run {
            call.reject("URL প্রদান করা হয়নি")
            return
        }
        val ctx = context ?: run {
            call.reject("অ্যান্ড্রয়েড কনটেক্সট পাওয়া যায়নি")
            return
        }
        try {
            val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            val ret = JSObject().apply {
                put("success", true)
            }
            call.resolve(ret)
        } catch (e: Exception) {
            call.reject("ব্রাউজার বা ডাউনলোডার খোলা সম্ভব হয়নি: ${e.message}")
        }
    }
}

